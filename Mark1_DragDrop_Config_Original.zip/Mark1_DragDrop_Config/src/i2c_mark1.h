/*
 * i2c_mark1.h
 *
 *  Created on: Dec 23, 2012
 *      Author: MJ
 */

#ifndef I2C_MARK1_H_
#define I2C_MARK1_H_


#define CMD_BB_CONFIG		0XA0
#define CMD_BB_CONFIG STAT 	0XA1





#endif /* I2C_MARK1_H_ */
