/*
 * FPGA_Config.h
 *
 */

#ifndef FPGA_CONFIG_H_
#define FPGA_CONFIG_H_

//ERRORS FOR THE FPGA CONFIGURATION
#define CONFIG_ERROR_FILE_NOT_FOUND	-1
#define CONFIG_ERROR_INIT_NOT_HIGH	-2
#define CONFIG_ERROR_DONE_NOT_HIGH	-3
#define CONFIG_OK

//PROTOTYPES
int8_t FPGA_Config(char * Filename);

#endif /* FPGA_CONFIG_H_ */

//EOF
